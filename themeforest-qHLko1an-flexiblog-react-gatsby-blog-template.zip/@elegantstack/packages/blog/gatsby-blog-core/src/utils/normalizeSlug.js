// normalize use of trailing slash
module.exports = slug => slug.replace(/\/*$/, `/`)
