export { default } from '../../../containers/Collection.Author'
