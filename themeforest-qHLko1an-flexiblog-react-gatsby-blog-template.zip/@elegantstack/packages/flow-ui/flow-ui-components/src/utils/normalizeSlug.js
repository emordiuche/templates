// normalize use of trailing slash
export default slug => slug.replace(/\/*$/, `/`)
