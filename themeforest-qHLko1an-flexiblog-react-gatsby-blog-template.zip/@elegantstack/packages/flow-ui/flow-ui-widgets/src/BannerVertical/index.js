export { default } from './BannerVertical'
