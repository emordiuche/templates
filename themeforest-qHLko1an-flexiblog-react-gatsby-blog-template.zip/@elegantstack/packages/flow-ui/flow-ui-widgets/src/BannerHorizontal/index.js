export { default } from './BannerHorizontal'
