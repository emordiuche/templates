export default ['640px', '768px', '1024px']
// export default ['576px', '768px', '992px', '1200px']
