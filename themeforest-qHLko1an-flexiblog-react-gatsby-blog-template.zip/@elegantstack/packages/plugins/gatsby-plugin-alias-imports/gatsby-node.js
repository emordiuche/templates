exports.onCreateWebpackConfig = require('./src/onCreateWebpackConfig')
