module.exports = pluginOptions => ({
  alias: pluginOptions.alias || {},
  extensions: pluginOptions.extensions || []
})
