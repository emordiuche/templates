module.exports = pluginOptions => ({
  basePath: pluginOptions.basePath || '/',
  sitePaths: pluginOptions.sitePaths || null
})
