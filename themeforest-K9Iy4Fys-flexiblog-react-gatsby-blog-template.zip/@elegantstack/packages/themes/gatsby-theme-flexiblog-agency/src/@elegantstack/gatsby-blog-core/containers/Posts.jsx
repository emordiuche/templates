export { default } from '../../../containers/Posts'
