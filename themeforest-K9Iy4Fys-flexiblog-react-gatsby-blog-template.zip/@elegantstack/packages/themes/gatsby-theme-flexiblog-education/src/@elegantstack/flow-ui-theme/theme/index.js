import theme from '@elegantstack/flow-ui-theme/src/theme/index'
import themeOverrides from '../../../theme'

export default themeOverrides(theme)
