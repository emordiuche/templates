export default {
  '> a + a, > button + button': {
    ml: 3,
    mt: [3, null, 0]
  }
}
