export { default } from './Divider'
