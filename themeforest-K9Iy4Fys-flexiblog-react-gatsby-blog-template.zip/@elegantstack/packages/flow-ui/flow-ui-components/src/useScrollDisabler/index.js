export { default } from './useScrollDisabler'
