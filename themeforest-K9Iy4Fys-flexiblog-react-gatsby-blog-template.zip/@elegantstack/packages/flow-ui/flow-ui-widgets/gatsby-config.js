module.exports = options => {
  return {
    plugins: ['gatsby-plugin-react-helmet']
  }
}
