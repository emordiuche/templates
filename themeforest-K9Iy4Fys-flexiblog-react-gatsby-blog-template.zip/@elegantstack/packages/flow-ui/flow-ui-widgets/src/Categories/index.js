export { default } from './Categories'
