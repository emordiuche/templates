export { default } from './BannerWide'
